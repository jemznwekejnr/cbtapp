<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     *
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    


    

    public function validateaccount(Request $request){

        //dd($request);

        $checkbank = DB::table('users')->where([['account', $request->account], ['bank', $this->getbankname($request->bank)]])->count();
        //var_dump($request);

        if($checkbank > 0){

            //var_dump($request);
            return response()->json([
                        'status' => false,
                        'message' => 'Account details already in use.',
                        'class_name' => 'alert-danger'
                    ]);
        
        }else{

        $result = array();
        //The parameter after verify/ is the transaction reference to be verified
        $url = 'https://api.paystack.co/bank/resolve?account_number='.$request->account.'&bank_code='.$request->bank;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt(
          $ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer sk_live_443a5911fa4f0b8e58fc6c35a7a96337c5a68ac4']
        );
        $request = curl_exec($ch);
        curl_close($ch);
        
        if ($request) {
            $result = json_decode($request, true);
            // print_r($result);
            if($result){
                //something came in
                if($result['status'] == true && strtoupper($result['data']['account_name']) != 'DEFAULT'){

                    $status = $result['status'];
                    $account = $result['data']['account_name'];

                    return response()->json([
                        'status' => $status,
                        'account' => $account,
                        'message' => 'Account verified successfully',
                        'class_name' => 'alert-success'
                    ]);

                }else{
                  // the transaction was not successful, do not deliver value'
                  // print_r($result);  //uncomment this line to inspect the result, to check why it failed.
                  return response()->json([
                        'status' => false,
                        'message' => 'Account verification failed',
                        'class_name' => 'alert-danger'
                    ]);
                }
        
            }else{
              //print_r($result);
              return response()->json([
                        'status' => false,
                        'message' => 'Account verification failed',
                        'class_name' => 'alert-danger'
                    ]);
            }
          }else{
            //var_dump($request);
            return response()->json([
                        'status' => false,
                        'message' => 'Account verification failed',
                        'class_name' => 'alert-danger'
                    ]);
          }

        }
    }

    public function transactions(){

        return view('transactions');
    }
}
