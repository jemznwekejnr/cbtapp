<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

use DB;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public static function reportthisyear($agency){

    	$year = date('Y');

    	return DB::table('userreport')
    				->where([
    							['SourceofReportText', $agency], 
    							['DateofReport', 'LIKE', '%'.$year]
    						])->count();
    }


    public static function reportlastyear($agency){

    	$year = date('Y') - 1;

    	return DB::table('userreport')
    				->where([
    							['SourceofReportText', $agency], 
    							['DateofReport', 'LIKE', '%'.$year]
    						])->count();

    }

    public static function banks(){

        $banks = array(
                        '044' => 'Access Bank',
                        '063' => 'Access Bank (Diamond)',
                        '035A' => 'ALAT by WEMA',
                        '401' => 'ASO Savings and Loans',
                        '50823' => 'CEMCS Microfinance Bank',
                        '023' => 'Citibank Nigeria',
                        '050' => 'Ecobank Nigeria',
                        '562' => 'Ekondo Microfinance Bank',
                        '070' => 'Fidelity Bank',
                        '011' => 'First Bank of Nigeria',
                        '214' => 'First City Monument Bank',
                        '00103' => 'Globus Bank',
                        '058' => 'Guaranty Trust Bank',
                        '50383' => 'Hasal Microfinance Bank',
                        '030' => 'Heritage Bank',
                        '301' => 'Jaiz Bank',
                        '082' => 'Keystone Bank',
                        '50211' => 'Kuda Bank',
                        '526' => 'Parallex Bank',
                        '076' => 'Polaris Bank',
                        '101' => 'Providus Bank',
                        '125' => 'Rubies MFB',
                        '51310' => 'Sparkle Microfinance Bank',
                        '221' => 'Stanbic IBTC Bank',
                        '068' => 'Standard Chartered Bank',
                        '232' => 'Sterling Bank',
                        '100' => 'Suntrust Bank',
                        '302' => 'TAJ Bank',
                        '51211' => 'TCF MFB',
                        '102' => 'Titan Bank',
                        '032' => 'Union Bank of Nigeria',
                        '033' => 'United Bank For Africa',
                        '215' => 'Unity Bank',
                        '566' => 'VFD',
                        '035' => 'Wema Bank',
                        '057' => 'Zenith Bank'
                    );

        
        return $banks;
    }


    public static function checkaccount($account, $bank){

        $checkbank = DB::table('users')->where([['account', $account], ['bank', $bank]])->count();

        if($checkbank > 0){

            return 'exist';

        }else{

            return 'notexist';

        }

    }


    public static function getbankname($code){

        $bankname = DB::table('banks')->where('bankcode', $code)->value('bankname');

        return $bankname;
    }

    public static function totalinvestment(){

        //$bankname = DB::table('banks')->where('bankcode', $code)->value('bankname');

        return 0.00;
    }

    public static function expectedreturns(){

        //$bankname = DB::table('banks')->where('bankcode', $code)->value('bankname');

        return 0.00;
    }

    public static function totalwithdrawal(){

        //$bankname = DB::table('banks')->where('bankcode', $code)->value('bankname');

        return 0.00;
    }

    public static function referralbonus(){

        //$bankname = DB::table('banks')->where('bankcode', $code)->value('bankname');

        return 0.00;
    }

    public static function getMessages(){

        return 0;
    }


    public static function initialinvestment($user){

        return DB::table('pledges')->where('userid', $user)->get();
    }

    public static function withdrawaldate($date){

        //add 3days to this date
        $date=date_create($date);
        date_add($date,date_interval_create_from_date_string("3 days"));
        return date_format($date,"Y-m-d H:i:s");
    }

    public static function progresstimeleft($date){

        //add 3days to this date
        $created = date_create($date);
        $withdraw = date_create($date);
        $withdraw = date_add($withdraw,date_interval_create_from_date_string("3 days"));
        $withdraw = date_format($withdraw,"Y-m-d H:i:s");

        $dates1 = $date;
        $dates2 = $withdraw;
        $timestamps1 = strtotime($dates1);
        $timestamps2 = strtotime($dates2);
        $hours = abs($timestamps2 - $timestamps1)/(60*60);

        //get current time
        $date1 = $created;
        $date2 = date('Y-m-d H:i:s');
        $timestamp1 = strtotime($date);
        $timestamp2 = strtotime($date2);
        $hour = abs($timestamp2 - $timestamp1)/(60*60);

        $percent = $hour / $hours * 100;

        return $percent;
    }


    public function newbank(){

        $banks = array(
                        '044' => 'Access Bank',
                        '063' => 'Access Bank (Diamond)',
                        '035A' => 'ALAT by WEMA',
                        '401' => 'ASO Savings and Loans',
                        '50823' => 'CEMCS Microfinance Bank',
                        '023' => 'Citibank Nigeria',
                        '050' => 'Ecobank Nigeria',
                        '562' => 'Ekondo Microfinance Bank',
                        '070' => 'Fidelity Bank',
                        '011' => 'First Bank of Nigeria',
                        '214' => 'First City Monument Bank',
                        '00103' => 'Globus Bank',
                        '058' => 'Guaranty Trust Bank',
                        '50383' => 'Hasal Microfinance Bank',
                        '030' => 'Heritage Bank',
                        '301' => 'Jaiz Bank',
                        '082' => 'Keystone Bank',
                        '50211' => 'Kuda Bank',
                        '526' => 'Parallex Bank',
                        '076' => 'Polaris Bank',
                        '101' => 'Providus Bank',
                        '125' => 'Rubies MFB',
                        '51310' => 'Sparkle Microfinance Bank',
                        '221' => 'Stanbic IBTC Bank',
                        '068' => 'Standard Chartered Bank',
                        '232' => 'Sterling Bank',
                        '100' => 'Suntrust Bank',
                        '302' => 'TAJ Bank',
                        '51211' => 'TCF MFB',
                        '102' => 'Titan Bank',
                        '032' => 'Union Bank of Nigeria',
                        '033' => 'United Bank For Africa',
                        '215' => 'Unity Bank',
                        '566' => 'VFD',
                        '035' => 'Wema Bank',
                        '057' => 'Zenith Bank'
                    );

        foreach($banks as $arr => $var){

            DB::table('banks')->insert(['bankcode' => $arr, 'bankname' => $var]);
        }
    }

    public static function getuserdetails($user){

        return DB::table('users')->where('id', $user)->get();
    }

    public static function usernames($user){

        return DB::table('users')->where('id', $user)->value('name');

    }

    public static function userphone($user){

        return DB::table('users')->where('id', $user)->value('phone');

    }

    public static function bankname($user){

        return DB::table('users')->where('id', $user)->value('bank');

    }

    public static function accountno($user){
        

        return DB::table('users')->where('id', $user)->value('account');

    }

    public static function investmentwithdrawal($user){

        return DB::table('users')->where(['id', $user], ['status', 'Available for Merging'])->count();
    }
}
