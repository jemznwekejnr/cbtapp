<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

use DB;

use Auth;

use Validator;

class transactionController extends Controller
{
    //
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

    public function index()
    {
        $checkmerged = DB::table('merging')->where([['payersid', Auth::user()->id], ['payerspledgeid', 'Activation']])->get();

        $checkmerging = DB::table('merging')->get();

        if($checkmerged->count() == 1){

            $recipient = DB::table('users')->where('id', $checkmerged[0]->recipientid)->get();

            //$payer = DB::table('users')->where('id', $checkmerged[0]->payersid)->get();

            return view('dashboard', ['checkmerged' => $checkmerged, 'recipient' => $recipient, 'checkmerging' => $checkmerging]);

        }else{

            return view('dashboard', ['checkmerging' => $checkmerging]);
        }

        
    }

    public static function mergeripeduser(){

            //create new merging
      return $ripeduser = DB::table('dueforpayment')
                    ->where('status', 'Available for Merging')
                    ->orderBy('created_at', 'asc')
                    ->limit(1)->get();
    }

    public function mergeuser(Request $request){

        //dd($request);

        if($request->type == 'Account Activation'){
    	//check if this user has meen merged
    	$checkmerged = DB::table('merging')
                ->where([
                            ['payersid', Auth::user()->id], 
                            ['amount', $request->amount], 
                            ['transactiontype', $request->type]
                    ])->get();

        }else if($request->type == 'Pledge'){
        //check if this user has meen merged
        $checkmerged = DB::table('merging')
                ->where([
                            ['payersid', Auth::user()->id], 
                            ['amount', $request->amount],
                            ['payerspledgeid', $request->id], 
                            ['transactiontype', $request->type]
                    ])->get();

        }

    	if($checkmerged->count() == 1){

    		$userdetails = $this->getuserdetails($checkmerged[0]->recipientid);

    		$username = $userdetails[0]->name;
    		$userphone = $userdetails[0]->phone;
    		$useraccount = $userdetails[0]->account;
    		$userbank = $userdetails[0]->bank;

    		//return records
    		return response()->json([
    			'message' => 'Merged',
    			'userid' => $checkmerged[0]->recipientid,
    			'pledgeid' => $checkmerged[0]->recipientpledgeid,
    			'amount' => $checkmerged[0]->amount,
                'mergetime' => $checkmerged[0]->created_at,
    			'username' => $username,
    			'userphone' => $userphone,
    			'useraccount' => $useraccount,
    			'userbank' => $userbank,
    		]);
    	}else{

            $assignedamount = $request->amount; 

            while($assignedamount > 0){

                $nextamount = $assignedamount;

                $ripeduser = $this->mergeripeduser();

                if($ripeduser->count() == 1){

                    $balance = $ripeduser[0]->totalamount - $ripeduser[0]->amountassigned;

                if($balance == $assignedamount || $balance > $assignedamount){

                    $newamount = $assignedamount;
                    $assignedamount = 0;

                }else if($assignedamount > $balance){

                    //get the amount to assign from the amount entered by user
                    $assignedamount = $assignedamount - $balance;
                    $newamount = $nextamount - $assignedamount;
                }


                if($request->id != 'Activation'){
                    $pledgeid = $request->id;
                }else{
                    $pledgeid = 'Activation';
                }


                $data = array();

                $data['recipientid'] = $ripeduser[0]->userid;
                $data['recipientpledgeid'] = $ripeduser[0]->pledgeid;
                $data['amount'] = $newamount;
                $data['status'] = 'Waiting for Payment';
                $data['transactiontype'] = $request->type;
                $data['payersid'] = Auth::user()->id;
                $data['payerspledgeid'] = $pledgeid;
                $data['created_at'] = date('Y-m-d H:i:s');

                $mergeuser = DB::table('merging')->insert($data);

                if($balance == $newamount){

                    $recieved = $ripeduser[0]->amountassigned + $newamount;

                    $updatedues = DB::table('dueforpayment')
                                    ->where('id', $ripeduser[0]->id)
                                    ->update(['amountassigned' => $recieved, 'status' => 'Merged']);
                }else{

                    $recieved = $ripeduser[0]->amountassigned + $newamount;

                    $updatedues = DB::table('dueforpayment')
                                    ->where('id', $ripeduser[0]->id)
                                    ->update(['amountassigned' => $recieved]);
                }

                /*if($request->type == 'Pledge'){

                    //update amount pledged on the pledge table

                }*/

                if($request->type == 'Account Activation'){

                //check if this user has meen merged
                $checkmerged = DB::table('merging')->where([['payersid', Auth::user()->id], ['payerspledgeid', 'Activation']])->get();

                //return records
                $userdetails = $this->getuserdetails($checkmerged[0]->recipientid);

                $username = $userdetails[0]->name;
                $userphone = $userdetails[0]->phone;
                $useraccount = $userdetails[0]->account;
                $userbank = $userdetails[0]->bank;

                //return records
                return response()->json([
                    'message' => 'Merged',
                    'userid' => $checkmerged[0]->recipientid,
                    'pledgeid' => $checkmerged[0]->recipientpledgeid,
                    'amount' => $checkmerged[0]->amount,
                    'mergetime' => $checkmerged[0]->created_at,
                    'username' => $username,
                    'userphone' => $userphone,
                    'useraccount' => $useraccount,
                    'userbank' => $userbank,
                ]);

            }

            }else{
                //return records
                return response()->json([
                    'message' => 'We could not complete your merging at the moment please try again in few minutes.',
                ]);

            }

            if($assignedamount == 0){
                return redirect('home');
            }

            }


    		return redirect('home');

    	}

        return redirect('home');
    }

    public function activationdeactivateuser(){

        //suspend user

        $suspend = DB::table('users')->where('id', Auth::user()->id)->update(['status' => 'Suspended']);

        $merging = DB::table('merging')
                    ->where([
                                ['payersid', Auth::user()->id], 
                                ['payerspledgeid', 'Activation'], 
                                ['status', 'Waiting for Payment']])
                    ->get();

        $dueforpayment = DB::table('dueforpayment')
                    ->where([
                                ['userid', $merging[0]->recipientid], 
                                ['pledgeid', $merging[0]->recipientpledgeid]
                            ])
                    ->decrement('amountassigned', 1000);

        $dueforpayment = DB::table('dueforpayment')
                    ->where([
                                ['userid', $merging[0]->recipientid], 
                                ['pledgeid', $merging[0]->recipientpledgeid]
                            ])
                    ->update(['status' => 'Available for Merging']);

        $merging = DB::table('merging')
                    ->where([
                                ['payersid', Auth::user()->id], 
                                ['payerspledgeid', 'Activation'], 
                                ['status', 'Waiting for Payment']])
                    ->update(['status' => 'Canceled']);
    }

    public function activationpayment(){

        
        $merging = DB::table('merging')
                    ->where([
                                ['payersid', Auth::user()->id], 
                                ['payerspledgeid', 'Activation'], 
                                ['status', 'Waiting for Payment']])
                    ->update(['status' => 'Payment Completed', 'updated_at' => date('Y-m-d H:i:s')]);


        $user = DB::table('merging')
                    ->where([
                                ['payersid', Auth::user()->id], 
                                ['payerspledgeid', 'Activation'], 
                                ['status', 'Payment Completed']])
                    ->value('recipientid');


        $usermerge = DB::table('merging')
                    ->where([
                                ['payersid', Auth::user()->id], 
                                ['payerspledgeid', 'Activation'], 
                                ['status', 'Payment Completed']])
                    ->get();

        
            $data = array();

            $data['pledgid'] = 'Activation';
            $data['userid'] = Auth::user()->id;
            $data['amount'] = 1000.00;
            $data['transactiontype'] = 'Account Activation';
            $data['paymentstatus'] = 'Payment Completed';
            $data['recipientid'] = $usermerge[0]->recipientid;
            $data['recipientpledgeid'] = $usermerge[0]->recipientpledgeid;
            $data['created_at'] = date('Y-m-d H:i:s');

            $newpayment = DB::table('payments')->insert($data);
            



        //email user of this payment
        if($merging){

            $updateregpayment = DB::table('users')
                            ->where('id', Auth::user()->id)
                            ->update([
                                        'regpayment' => 1000.00, 
                                        'paymentstatus' => 'Pending Confirmation'
                                    ]);

            $userdetails = DB::table('users')->where('id', $user)->get();

            $name = $userdetails[0]->name;
            $email = $userdetails[0]->email;
            $amount = 1000.00;
            $member = Auth::user()->id;

            

            return response()->json([
                'message' => 'Success',
                'name' => $name
            ]);

            /*try{
                //send email to the person concerned
                Mail::send('emails.cooperativesaveemail', ['name' => $name, 'email' => $email, 'amount' => $amount, 'member' => $member], function ($message) use ($name, $email, $amount, $member) {
                $message->to($useremail, $username)->subject('New Payment Notification');
                $message->from('admin@amaniwomen.org', 'Amani Women');
                });
                }catch(\Exception $e){
                        //return success message
                        return response()->json([
                            'message' => 'Your monthly cooperative savings have been successfully set to &#x20a6;'.$amount,
                            'class_name' => 'alert-success btn-round'
                        ]);
                    }*/
        }
    }


    public function confirmpaymentrequest(Request $request){

        $updatemerging = DB::table('merging')
                            ->where('id', $request->id)
                            ->update(['status' => 'Payment Confirmed']);

        $mergedetails = DB::table('merging')->where('id', $request->id)->get();

        //update pledges
        $pledgeupdates = DB::table('pledges')
                    ->where([
                                ['id', $mergedetails[0]->recipientpledgeid], 
                                ['userid', $mergedetails[0]->recipientid]
                            ])
                    ->increment('totalrecieved', $mergedetails[0]->amount);

        //get pledge details
        $pledgeupdate = DB::table('pledges')
                    ->where([
                                ['id', $mergedetails[0]->recipientpledgeid], 
                                ['userid', $mergedetails[0]->recipientid]
                            ])
                    ->get();

        if($pledgeupdate[0]->returns == $pledgeupdate[0]->totalrecieved){

            $updatestatus = DB::table('pledges')
                    ->where([
                                ['id', $mergedetails[0]->recipientpledgeid], 
                                ['userid', $mergedetails[0]->recipientid]
                            ])
                    ->update(['status' => 'Transaction Completed', 'updated_at' => date('Y-m-d H:i:s')]);
        }


        //update payments
        $updatepayments = DB::table('payments')
                        ->where([
                                    ['recipientid', $mergedetails[0]->recipientid],
                                    ['recipientpledgeid', $mergedetails[0]->recipientpledgeid]
                                ])
                        ->update(['paymentstatus' => 'Payment Confirmed', 'updated_at' => date('Y-m-d H:i:s')]);

        if($mergedetails[0]->transactiontype == 'Account Activation'){
            //update user
            $updateuser = DB::table('users')
                    ->where('id', $mergedetails[0]->payersid)
                    ->update(['status' => 'Beginner', 'paymentstatus' => 'Confirmed']);

        }else if($mergedetails[0]->transactiontype == 'Pledge'){
            //update pledge
            $pledgedetails = DB::table('pledges')
                    ->where([['userid', $mergedetails[0]->payersid], ['id', $mergedetails[0]->payerspledgeid]])
                    ->get();

            if($pledgedetails[0]->amount == $pledgedetails[0]->totalpaid){

                $updatepledge = DB::table('pledges')
                    ->where([['userid', $pledgedetails[0]->userid], ['id', $pledgedetails[0]->id]])
                    ->update(['status' => 'Waiting for Returns', 'updated_at' => date('Y-m-d H:i:s')]);

                $checkdue = DB::table('dueforpayment')
                                ->where([
                                            ['pledgeid', $pledgedetails[0]->id], 
                                            ['userid', $pledgedetails[0]->userid]
                                        ])->count();

                if($checkdue == 0){
                    //add to due for payments
                    $data = array();

                    $data['userid'] = $pledgedetails[0]->userid;
                    $data['pledgeid'] = $pledgedetails[0]->id;
                    $data['totalamount'] = $pledgedetails[0]->returns;
                    $data['amountassigned'] = 0;
                    $data['status'] = 'Available for Merging';
                    $data['created_at'] = date('Y-m-d H:i:s');

                    $due = DB::table('dueforpayment')->insert($data);

                }
            }

            

        }


        if($pledgeupdates){

            return response()->json([
                'message' => 'Payment Confirmed Successfully',
            ]);
        }
    }


    public function updatepaymentproof(Request $request){

        if($request->type == 'activation'){

            $merging = DB::table('merging')
                    ->where([
                                ['payersid', Auth::user()->id], 
                                ['payerspledgeid', 'Activation']
                            ])
                    ->get();


            $user = DB::table('users')->where('id', $merging[0]->recipientid)->get();

        }else if($request->type == 'pledge'){

            $merging = DB::table('merging')
                    ->where('id', $request->id)
                    ->get();


            $user = DB::table('users')->where('id', $merging[0]->recipientid)->get();

        }


            return view('updatepaymentproof', ['merging' => $merging, 'user' => $user]);
        
    }


    public function submitpaymentproof(Request $request){

        //dd($request);

        $validator =    Validator::make($request->all(), [

                            'proof' => 'required',

                        ]);

        if($validator->passes()){

            $proof = $request->file('proof');

            $proofurl = $proof->store('assets/attachments');

            $mergestatus = $updatemerging = DB::table('merging')->where('id', $request->id)->value('status');

            
            //update merging
            $updatemerging = DB::table('merging')
                    ->where('id', $request->id)
                    ->update(['paymentproof' => $proofurl, 'status' => 'Payment Completed', 'updated_at' => date('Y-m-d H:i:s')]);

            if($mergestatus == 'Waiting for Payment'){

                if($updatemerging){

                    if($request->pledgeid != 'Activation'){
                        $pledgeid = $request->pledgeid;
                    }else{
                        $pledgeid = 'Activation';
                    }

                    //insert into payment table
                    $merging = DB::table('merging')->where('id', $request->id)->get();

                    $data = array();

                    $data['pledgeid'] = $pledgeid;
                    $data['userid'] = Auth::user()->id;
                    $data['amount'] = $request->amount;
                    $data['transactiontype'] = $request->transaction;
                    $data['paymentstatus'] = 'Payment Completed';
                    $data['recipientid'] = $merging[0]->recipientid;
                    $data['recipientpledgeid'] = $merging[0]->recipientpledgeid;
                    $data['created_at'] = date('Y-m-d H:i:s');

                    $newpayment = DB::table('payments')->insert($data);


                    if($request->transaction == 'Account Activation'){

                        //update user
                        $updateuser = DB::table('users')
                                ->where('id', Auth::user()->id)
                                ->update(['regpayment' => $request->amount, 'paymentproof' => $proofurl, 'paymentstatus' => 'Pending Confirmation']);

                    }else if($request->transaction == 'Pledge'){

                        //update user
                        $updateuser = DB::table('pledges')
                                ->where([['userid', Auth::user()->id], ['id', $request->pledgeid]])
                                ->increment('totalpaid', $request->amount);


                        $pledgedetails = DB::table('pledges')
                                ->where([['userid', Auth::user()->id], ['id', $request->pledgeid]])
                                ->get();

                        if($pledgedetails[0]->amount == $pledgedetails[0]->totalpaid){
                            //update user
                        $updateuser = DB::table('pledges')
                                ->where([['userid', Auth::user()->id], ['id', $request->pledgeid]])
                                ->update(['status' => 'Payment Completed']);
                        }

                    }

                        

                }else{

                    return response()->json([
                        'message' => 'Payment could not be updated at the moment, please try again',
                        'class_name' => 'alert-danger'
                    ]);
                }

            }

            return response()->json([
                        'message' => 'success',
                        'class_name' => 'alert-success'
                    ]);

        }else{

            return response()->json([
                'message' => $validator->errors()->all(),
                'class_name' => 'alert-danger'
            ]);
        }

        
    }

    public function filedispute(Request $request){

        $mergedetails = DB::table('merging')->where('id', $request->id)->get();

        if(Auth::user()->id == $mergedetails[0]->payersid){

            $recipient = DB::table('users')->where('id', $mergedetails[0]->recipientid)->get();

        }else if(Auth::user()->id == $mergedetails[0]->recipientid){

            $recipient = DB::table('users')->where('id', $mergedetails[0]->payersid)->get();
        }

        return view('filedispute', ['mergedetails' => $mergedetails, 'recipient' => $recipient]);
    }


    public function submitinvestment(Request $request){

        $validator = Validator::make($request->all(), [

            'amount' => 'required'
        ]);

        if($validator->passes()){

            $amount = $request->amount;

            $retuns = $amount / 2 + $amount;

            $data = array();

            $data['userid'] = Auth::user()->id;
            $data['name'] = Auth::user()->name;
            $data['amount'] = $amount;
            $data['totalpaid'] = 0.00;
            $data['returns'] = $retuns;
            $data['totalrecieved'] = 0.00;
            $data['status'] = 'Waiting for Payment';
            $data['created_at'] = date('Y-m-d H:i:s');

            //create pledging
            $pledges = DB::table('pledges')->insertGetId($data);


            if($pledges){

                //merge user for payment
                return response()->json([
                    'message' => 'pledged',
                    'amount' => $amount,
                    'id' => $pledges,
                    'class_name' => 'alert-success'
                ]);

            }


        }else{

            return response()->json([
                'message' => $validator->errors()->all(),
                'class_name' => 'alert-danger'
            ]);
        }   
    }
}
